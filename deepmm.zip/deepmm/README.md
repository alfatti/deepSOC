# deepmm — Han & E deep stochastic control for the BEGV two-asset RFQ market maker

Applies the stacked-subnetwork policy learner of Han & E, *Deep Learning Approximation for
Stochastic Control Problems* (2016), to the two-asset RFQ market-making example of Bergault,
Evangelista, Guéant & Vieira, *Closed-form approximations in multi-asset market making*
(Section 6): Model B, drifts (+0.1, −0.1), vols (1.2, 0.6), ρ = 0.5, T = 7 days, γ = 8·10⁻⁶,
logistic RFQ intensity 30/day per (asset, side), 4-point request-size law, risk limits
(75k, 300k). The learned policy is benchmarked against the finite-difference optimum on the
25×97 inventory lattice and the paper's closed-form (asymptotic) quotes.

```
pip install -e ".[gpu,plots,test,nb]"     # jax[cuda12] for the A100
python -m pytest tests/test_core.py -q    # ~1 min on CPU
jupyter lab notebooks/deepmm_begv.ipynb   # <- the run: FD benchmark, training, all diagnostics
python scripts/run_a100.py --out runs/a100        # same pipeline headless
DEEPMM_RUN=runs/notebook_a100 python -m pytest tests/test_policy_behaviour.py -q   # on the trained run
```

`notebooks/deepmm_begv.ipynb` detects the backend: on the A100 it runs the full configuration
(Δt = 1/96, batch 16,384, 12k iterations, 10⁶ evaluation paths); on a CPU it drops to an hourly
grid and 20 iterations so every cell executes (`notebooks/deepmm_begv_quick_cpu.ipynb` is that
run, executed, with all figures — its training is meaningless, its plumbing is not).

## Formulation

* **State** `s_t = q_t ∈ ℝ²` (inventory); prices are integrated out analytically: with
  `dS = μ dt + σ dW` and `q_0 = 0`, `E[X_T + q_T·S_T] = E[Σ fills δ z + ∫ μᵀq dt]`, so
  `J = E[ Σ_t ( Σ_fills δ z + μᵀq_t Δt − ½γ q_tᵀΣq_t Δt ) ]` and the loss is `−J`.
* **Control** `a_t ∈ ℝ¹⁶` = quotes for (asset, side, size); layout `asset·8 + side·4 + size`.
* **Time grid** Δt = 1/96 day (672 steps). Step 0 has its own sub-network (constant input
  `q_0 = 0`, where Han & E skip BN); the remaining steps share weights in hourly blocks →
  169 sub-networks, each `2 → 100 → 100 → 16` with batch norm after the hidden linears.
* **Exogenous noise** per stream and step: Poisson arrival count (capped at 4), request
  sizes, fill uniforms — the `ξ_{t+1}` of Han & E. Risk limits are a state-dependent mask
  on fills applied sequentially within a step, not a penalty.

## The part Han & E did not need: gradients through Bernoulli fills

Han & E's dynamics are smooth in the control; here the control enters through the fill
indicator `1{u < p(δ)}`, whose pathwise gradient is zero a.e. — and the inventory-path
gradient is exactly what produces the skew. `sim.apply_fills` uses

* the conditional expectation `N·δ·z·p(δ)` for the immediate reward (exact pathwise
  gradient, no fill-draw variance), and
* a **straight-through** transition: hard fill in the forward pass (the simulated path is
  the true dynamics), `sigmoid((p(δ) − u)/τ)` in the backward pass, τ annealed 0.10 → 0.02.

Check performed (`config.TrainConfig` defaults, closed-form policy): along the asset-1 and
asset-2 skew directions the ST gradient has the sign and order of magnitude of a
common-random-number finite difference (ST ≈ 340–420 vs FD ≈ 480 for asset-1 skew).
The CRN finite difference is itself jumpy in this problem (each fill flip is a jump in the
sampled loss), so this is a plausibility check, not a bias measurement. If the A100 run
does not improve on the warm start, the fallback is a score-function estimator with the
closed-form value `θ̌` as baseline (`sim.py` is structured so that only `apply_fills` and
the loss change).

## Warm start from the closed form (and a batch-norm trap)

`train.warm_start_closedform` fits every sub-network to the **finite-horizon** closed-form
quotes of BEGV Proposition 5 (`closedform.ClosedForm.quotes_t`) at that block's time — the
same `A(t) = ½D₊^{-½} Â tanh(Â(T−t)) D₊^{-½}`, `B(t) = −Â⁺ tanh(Â(T−t)) μ` reduce to the
paper's asymptotic quotes at `t = 0` and to the myopic quote `δ*(0)` at `t = T`, so the
last-day blocks start with the right boundary layer.

The fit is done on the inventories each block's own steps visit under that policy. Fitting
on a uniform cloud over the risk box gives a network that is correct with running BN
statistics but wrong in training mode (train loss −218k vs eval +58k), because BN rescales
by batch statistics and the on-policy inventory distribution is concentrated near zero.

Adam's first, sign-like steps destroyed the warm start at Han & E's `lr = 1e-3` (100 hidden
units × 1e-3 per step on the output weights = cents per step on every quote). Defaults are
therefore a 300-iteration linear LR warm-up and peak `lr = 3e-4`.

## Measuring the fit: quote gaps, Bellman regret, behavioural checks

`deepmm/diagnostics.py`, used by the notebook (§6–8) and `tests/test_policy_behaviour.py`:

* **Time-indexed quote gap** — simulate the network; at every step compare its quotes with the FD
  optimum *at the visited state* over paths × feasible controls; half-day box plots of
  |δ_NN − δ_FD| (5/25/50/75/95 %), with the closed form on the same trajectories as reference.
* **One-step Bellman regret rate** (EUR/day) — with the FD value function the loss from quoting δ
  instead of δ* is exact: Σ p_k z_k [H(p) − Λ(δ)(δ − p)] ≥ 0 with p the FD shadow price at
  (t, q_t). Its time integral is the first-order value loss of the policy. This is the metric that
  can actually see the difference between policies: FD self-check ≈ 0.4 €, closed form ≈ 70 €,
  on a 58.5k objective — a 0.1 % effect that PnL sampling cannot resolve at any feasible sample
  size (SE ≈ 275 € at 10⁵ paths). Training therefore reports it at every validation and selects
  the checkpoint on it. Scale: with β = 30/€, a 1-cent error on every quote costs ≈ 180 €/day.
* **Behavioural checks** on the visited region (all thresholds calibrated on the FD optimum):
  own-inventory monotonicity (bid up / ask down in q_i), cross-asset monotonicity (ρ > 0), size
  ordering agreeing with FD, drift asymmetry at q = 0 (μ₁ > 0 ⇒ asset-1 bid tighter than ask;
  μ₂ < 0 the opposite), stationarity between two ergodic-regime sub-networks (2 d vs T−3 d, p99 <
  1 c), terminal boundary layer, and the fit-quality checks: median / p95 gap and integrated
  regret no worse than the closed form the network was warm-started from.

Two consequences of Han & E's fixed q₀ = 0 show up in these diagnostics and are handled: the
step-0 sub-network only ever sees q = 0 (its BN statistics are degenerate — never evaluate it
elsewhere), and the first hours' sub-networks only see a small neighbourhood of zero, so
slices and the stationarity check use mid-horizon sub-networks.

## Benchmarks and what "good" looks like

* `fd.solve_fd` — explicit monotone Euler on the lattice (dt = 1/1920 day, ~15 s). At
  `q = 0`: `θ(0,0) = 58,523 €` = the optimal Model-B objective. Reproduces the paper's
  black curves (asset-2 bid ≈ 0.6–0.7 at large q², stationary from day 0 to 6).
* `closedform.ClosedForm` — reproduces the paper's grey curves (asset-1 bid 0.018 at q=0,
  0.19–0.22 at q¹=75k; asset-2 bid 0.45 at q²=300k). Objective from zero inventory ≈ 55–58k.
* **The prize is small**: ≈ 1–3k on an 87k PnL standard deviation. The paper's 88.6k vs
  89.0k over 4,000 paths (SE ≈ 1.4k) does not resolve it. `evaluate.compare_policies`
  therefore runs 10⁶ paths with common random numbers and reports **paired** differences
  with standard errors for `fd_optimal`, `closedform`, `closedform_fh`, `nn`.
* Quote slices (`quote_slices`) reproduce Figs. 8–11 with the network as a third curve;
  `visitation` shows where the fixed-`q_0` network was actually trained — slices outside the
  visited region are extrapolation and should be read as such.

## Status

Validated on CPU at small scale: the notebook executes end to end; unit tests pass; the
warm-started network reproduces the closed form to 0.2–0.3 c (median) on visited states and is
stable under Adam with warm-up. Its integrated regret at iteration 0 is ~140 € vs ~70 € for the
closed form it was fitted to — i.e. the regression precision (≈ 0.3 c) is the initial floor, and
the network has to reach sub-0.1-c precision on visited states to beat the closed form. Whether
the straight-through gradient gets it there, and closes the large-|q²| gap the closed form leaves,
is what the A100 run answers (~1 h for 12k iterations at batch 16,384 with rematerialisation).

## What gets written to disk

Only model checkpoints (`best.pkl`, `final.pkl` — the 169 stacked sub-networks, ~9 MB each),
`log.txt` and figures. The FD solution (~15 s) and all diagnostics are recomputed on the fly by
the notebook, `scripts/run_a100.py` and `tests/test_policy_behaviour.py` whenever they are needed.

## Layout

```
deepmm/config.py      MarketConfig (BEGV example), TrainConfig (Han & E set-up)
deepmm/intensity.py   logistic Λ, Model-B Hamiltonian H(p), maximiser δ*(p), interpolation table
deepmm/closedform.py  asymptotic (eqs. 29-30) and finite-horizon (Prop. 5) closed-form quotes
deepmm/fd.py          finite-difference optimum on the inventory lattice + lattice policy
deepmm/policy.py      stacked Han & E sub-networks with batch norm
deepmm/sim.py         noise, fills (straight-through), training loss, hard-fill evaluation rollout
deepmm/train.py       warm start, Adam with warm-up, τ annealing, validation, checkpoints
deepmm/evaluate.py    paired CRN comparison, quote slices, time profile, visitation
deepmm/diagnostics.py time-indexed quote gaps, Bellman regret, behavioural checks
notebooks/            deepmm_begv.ipynb (the run) and its executed CPU quick version
scripts/run_a100.py   headless end-to-end run; scripts/figures.py plots
tests/test_core.py    9 unit tests (maximiser, comparative statics, finite-horizon limits, FD, accounting, ST)
tests/test_policy_behaviour.py  16 checks on a trained checkpoint (DEEPMM_RUN=<run dir>)
```
