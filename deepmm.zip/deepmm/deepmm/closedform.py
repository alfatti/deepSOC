"""BEGV asymptotic closed-form quotes (Section 5.4, eqs. (29)-(30)) for Model B with
symmetric intensities, one tier, no fixed costs.

With Lambda^{i,b} = Lambda^{i,a} identical across assets and Model B (xi = 0):
    alpha_j = H^{(j)}(0)                     (size-independent, Remark 2)
    Delta_{j,k} = alpha_j * E[z^k]
    D_+ = diag(2 alpha_2 E[z])  =: d_plus * I
    Ahat = sqrt(gamma) (D_+^{1/2} Sigma D_+^{1/2})^{1/2} = sqrt(gamma d_plus) Sigma^{1/2}
    Gamma = D_+^{-1/2} (D_+^{1/2} Sigma D_+^{1/2})^{1/2} D_+^{-1/2} = Sigma^{1/2} / sqrt(d_plus)
    drift term  e_i' D_+^{-1/2} Ahat^+ D_+^{1/2} mu = (Ahat^+ mu)_i

Quotes (greedy w.r.t. the asymptotic quadratic proxy):
    delta^b_i(z) = delta*( +sqrt(g) q'Gamma e_i + 1/2 sqrt(g) z Gamma_ii - (Ahat^+ mu)_i )
    delta^a_i(z) = delta*( -sqrt(g) q'Gamma e_i + 1/2 sqrt(g) z Gamma_ii + (Ahat^+ mu)_i )
where delta*(p) = argmax_delta Lambda(delta)(delta - p) = Lambda^{-1}(-H'(p)).

Finite-horizon version (Proposition 5 with V_- = D_- = Vtilde_- = 0, D_+ = d_plus I):
    A(t) = (1 / 2 d_plus) Ahat tanh(Ahat (T - t))
    B(t) = -Ahat^+ tanh(Ahat (T - t)) mu           (B' = mu + 2 d_plus A B, B(T) = 0)
so with Ahat = P diag(lambda_i) P' both are diagonal in Sigma's eigenbasis, and the greedy
quotes of Section 5.4.1 are
    delta^b_i(t, z) = delta*( 2 q'A(t) e_i + z A_ii(t) + B_i(t) )
    delta^a_i(t, z) = delta*(-2 q'A(t) e_i + z A_ii(t) - B_i(t) ).
As T - t -> inf these reduce to the asymptotic quotes above; at t = T they are the myopic
quotes delta*(0).
"""
from __future__ import annotations

from dataclasses import dataclass

import jax.numpy as jnp
import numpy as np
from scipy.linalg import sqrtm

from .config import MarketConfig
from .intensity import HamiltonianTable, hamiltonian_derivs_at


@dataclass(frozen=True)
class ClosedForm:
    mc: MarketConfig
    alpha: tuple            # (H(0), H'(0), H''(0))
    d_plus: float
    Gamma: np.ndarray       # (d, d)
    drift_shift: np.ndarray # (d,)  = Ahat^+ mu
    table: HamiltonianTable
    P: np.ndarray           # eigenvectors of Sigma (columns)
    lam: np.ndarray         # eigenvalues of Ahat = sqrt(gamma d_plus) * sqrt(eig(Sigma))

    @staticmethod
    def build(mc: MarketConfig, table: HamiltonianTable | None = None) -> "ClosedForm":
        a0, a1, a2 = hamiltonian_derivs_at(0.0, mc)
        if a2 <= 0:
            raise ValueError("H''(0) must be positive for the quadratic proxy (got %g)" % a2)
        Ez = float(np.dot(mc.sizes, mc.size_probs))
        d_plus = 2.0 * a2 * Ez
        Sig = mc.Sigma
        Sig_half = np.real(sqrtm(Sig))
        Gamma = Sig_half / np.sqrt(d_plus)
        Ahat = np.sqrt(mc.gamma * d_plus) * Sig_half
        drift_shift = np.linalg.pinv(Ahat) @ np.asarray(mc.mu)
        table = table or HamiltonianTable.build(mc)
        w, P = np.linalg.eigh(Sig)
        lam = np.sqrt(mc.gamma * d_plus) * np.sqrt(np.maximum(w, 0.0))
        return ClosedForm(mc=mc, alpha=(a0, a1, a2), d_plus=d_plus, Gamma=Gamma,
                          drift_shift=drift_shift, table=table, P=P, lam=lam)

    # ------------------------------------------------------------- finite-horizon (A, B)
    def AB(self, t):
        """A(t) (d, d) and B(t) (d,) of the finite-horizon quadratic proxy, Proposition 5."""
        mc = self.mc
        P = jnp.asarray(self.P, jnp.float32)
        lam = jnp.asarray(self.lam, jnp.float32)
        mu = jnp.asarray(mc.mu, jnp.float32)
        tau = jnp.asarray(mc.T - t, jnp.float32)
        th = jnp.tanh(lam * tau)                                 # (d,)
        A = (P * (lam * th)[None, :]) @ P.T / (2.0 * self.d_plus)
        # Ahat^+ tanh(Ahat tau) mu, with the lambda = 0 limit tanh(lam tau)/lam -> tau
        coef = jnp.where(lam > 1e-12, th / jnp.where(lam > 1e-12, lam, 1.0), tau)
        B = -(P * coef[None, :]) @ (P.T @ mu)
        return A, B

    def shadow_price_t(self, t, q):
        """Finite-horizon shadow prices, shape (..., d, 2, n_sizes)."""
        mc = self.mc
        A, B = self.AB(t)
        z = jnp.asarray(mc.sizes, jnp.float32)
        q = jnp.asarray(q, jnp.float32)
        qA = 2.0 * (q @ A)                                       # (..., d) = 2 q'A e_i
        half = z[None, :] * jnp.diag(A)[:, None]                 # (d, n_sizes)
        p_bid = qA[..., :, None] + half + B[:, None]
        p_ask = -qA[..., :, None] + half - B[:, None]
        return jnp.stack([p_bid, p_ask], axis=-2)

    def quotes_t(self, t, q):
        p = self.shadow_price_t(t, q)
        d = self.table.dstar_of(p)
        return d.reshape(d.shape[:-3] + (self.mc.n_controls,))

    def policy_finite_horizon(self, dt: float):
        """(t_idx, q) -> delta using the finite-horizon proxy at time t_idx * dt."""
        return lambda t_idx, q: self.quotes_t(t_idx * dt, q)

    # -------------------------------------------------------------------- shadow prices
    def shadow_price(self, q):
        """p for each (asset, side, size): shape (..., d, 2, n_sizes).  q: (..., d)."""
        mc = self.mc
        sg = np.sqrt(mc.gamma)
        G = jnp.asarray(self.Gamma, jnp.float32)
        z = jnp.asarray(mc.sizes, jnp.float32)
        q = jnp.asarray(q, jnp.float32)
        qG = q @ G                                              # (..., d)  = q' Gamma e_i
        half = 0.5 * sg * z[None, :] * jnp.diag(G)[:, None]     # (d, n_sizes)
        drift = jnp.asarray(self.drift_shift, jnp.float32)      # (d,)
        p_bid = sg * qG[..., :, None] + half - drift[:, None]
        p_ask = -sg * qG[..., :, None] + half + drift[:, None]
        return jnp.stack([p_bid, p_ask], axis=-2)               # (..., d, 2, n_sizes)

    def quotes(self, q):
        """Closed-form quotes, flattened to the control layout (..., n_controls)."""
        p = self.shadow_price(q)
        d = self.table.dstar_of(p)
        return d.reshape(d.shape[:-3] + (self.mc.n_controls,))

    def policy(self):
        """A (t, q) -> delta policy function usable by the simulator (time-independent)."""
        return lambda t, q: self.quotes(q)

    def summary(self) -> str:
        a0, a1, a2 = self.alpha
        return (f"H(0)={a0:.4f}  H'(0)={a1:.4f}  H''(0)={a2:.3f}\n"
                f"d_plus={self.d_plus:.4g}\nGamma=\n{self.Gamma}\n"
                f"drift shift (Ahat^+ mu) = {self.drift_shift}")
