"""Evaluation of the learned policy against the finite-difference optimum and the
closed-form approximation.

1. Paired PnL comparison with common random numbers (arrivals, sizes, fill uniforms and
   price shocks are identical across policies; only the fills that depend on the quotes
   differ), reported with standard errors.
2. Quote slices  delta^{i,b}(q^1, 0, z_k),  delta^{i,b}(0, q^2, z_k)  at t = 0, i.e. the
   paper's Figures 8-11 with the network added as a third curve.
3. Time-stationarity of the learned quotes at q = 0 (boundary layer near T).
4. State visitation: with q0 = 0 fixed (Han & E) the network is only trained where the
   trajectories go, so slices outside the visited region are extrapolation.
"""
from __future__ import annotations

from typing import Callable, Dict

import jax
import jax.numpy as jnp
import numpy as np

from .closedform import ClosedForm
from .config import MarketConfig, TrainConfig, n_steps_for
from .fd import FDSolution
from .sim import make_eval_rollout, summarize


def compare_policies(mc: MarketConfig, tc: TrainConfig, policies: Dict[str, Callable],
                     n_paths: int, seed: int = 2024, chunk: int = 32768, log=print) -> Dict[str, dict]:
    """Paired evaluation of several policies with common random numbers."""
    out = {name: {"pnl": [], "objective": [], "spread_pnl": [], "risk_penalty": [], "n_fills": [], "q_absmax": []}
           for name in policies}
    n_chunks = -(-n_paths // chunk)
    rollouts = {name: make_eval_rollout(mc, tc, lambda t, q, _p=pol: _p(t, q), min(chunk, n_paths))
                for name, pol in policies.items()}
    for c in range(n_chunks):
        key = jax.random.fold_in(jax.random.PRNGKey(seed), c)
        for name, ro in rollouts.items():
            r = ro(key)
            for k in out[name]:
                out[name][k].append(np.asarray(r[k]))
    for name in out:
        for k in out[name]:
            out[name][k] = np.concatenate(out[name][k], 0)
        log(summarize(out[name], name))
    names = list(policies)
    ref = names[0]
    for name in names[1:]:
        for k in ("objective", "pnl"):
            d = out[name][k] - out[ref][k]
            log(f"  {name} - {ref}  {k:9s}: {d.mean():8.0f} ± {d.std()/np.sqrt(d.size):6.0f}  (paired, n={d.size})")
    return out


def quote_slices(mc: MarketConfig, fd: FDSolution, cf: ClosedForm, nn_policy: Callable | None,
                 t_idx: int | None = None) -> Dict[str, np.ndarray]:
    """Bid quotes along the two inventory axes for both assets and all sizes at time index t_idx.
    Default: mid-horizon.  In the ergodic regime this equals the t = 0 optimum, and with q0 = 0
    fixed only the mid-horizon sub-networks have seen the whole visited region (the first hours'
    sub-networks are undefined away from zero).
    Returns arrays of shape (n_points, d_asset, n_sizes) keyed by axis and policy."""
    if t_idx is None:
        t_idx = fd.quotes.shape[0] // 2
    lat = fd.lattice
    res = {"q1": lat.q1, "q2": lat.q2}
    c1, c2 = lat.n[0] // 2, lat.n[1] // 2
    qa = np.stack([lat.q1, np.zeros_like(lat.q1)], -1)      # along q1, q2 = 0
    qb = np.stack([np.zeros_like(lat.q2), lat.q2], -1)      # along q2, q1 = 0
    fdq = fd.quotes[t_idx].reshape(*lat.n, mc.d, 2, mc.n_sizes)
    res["fd_along_q1"] = fdq[:, c2, :, 0, :]
    res["fd_along_q2"] = fdq[c1, :, :, 0, :]
    cfa = np.asarray(cf.quotes(jnp.asarray(qa, jnp.float32))).reshape(-1, mc.d, 2, mc.n_sizes)
    cfb = np.asarray(cf.quotes(jnp.asarray(qb, jnp.float32))).reshape(-1, mc.d, 2, mc.n_sizes)
    res["cf_along_q1"], res["cf_along_q2"] = cfa[:, :, 0, :], cfb[:, :, 0, :]
    if nn_policy is not None:
        nna = np.asarray(nn_policy(t_idx, jnp.asarray(qa, jnp.float32))).reshape(-1, mc.d, 2, mc.n_sizes)
        nnb = np.asarray(nn_policy(t_idx, jnp.asarray(qb, jnp.float32))).reshape(-1, mc.d, 2, mc.n_sizes)
        res["nn_along_q1"], res["nn_along_q2"] = nna[:, :, 0, :], nnb[:, :, 0, :]
    # feasibility masks for the bid (q + z <= Q)
    res["mask_along_q1"] = np.stack([lat.q1[:, None] + np.asarray(mc.sizes)[None, :] <= mc.Q[0],
                                     np.ones((lat.n[0], mc.n_sizes), bool)], 1)
    res["mask_along_q2"] = np.stack([np.ones((lat.n[1], mc.n_sizes), bool),
                                     lat.q2[:, None] + np.asarray(mc.sizes)[None, :] <= mc.Q[1]], 1)
    return res


def slice_errors(sl: Dict[str, np.ndarray], key: str, mask_key: str, ref: str = "fd") -> Dict[str, float]:
    """RMS quote error (EUR) vs the FD optimum over feasible lattice points."""
    m = sl[mask_key]
    out = {}
    for pol in ("cf", "nn"):
        if f"{pol}_{key}" in sl:
            e = (sl[f"{pol}_{key}"] - sl[f"{ref}_{key}"])[m]
            out[pol] = float(np.sqrt(np.mean(e**2)))
    return out


def time_profile(mc: MarketConfig, tc: TrainConfig, nn_policy: Callable, fd: FDSolution, q=None) -> Dict[str, np.ndarray]:
    """Quotes at a fixed inventory as a function of time (stationarity check)."""
    n = n_steps_for(mc, tc)
    q = np.zeros((1, mc.d), np.float32) if q is None else np.asarray(q, np.float32)[None]
    ts = np.arange(n) if q is None or not np.any(q) else np.arange(1, n)
    nn = np.stack([np.asarray(nn_policy(t, jnp.asarray(q)))[0] for t in ts], 0)
    i1, i2 = fd.lattice.index(jnp.asarray(q))
    fdq = fd.quotes[:, int(i1[0]), int(i2[0]), :]
    return {"t": tc.dt * ts, "nn": nn, "fd": fdq}


def visitation(mc: MarketConfig, tc: TrainConfig, policy: Callable, n_paths: int = 4096, seed: int = 99) -> np.ndarray:
    """2-D histogram of visited inventories on the lattice under `policy`."""
    ro = make_eval_rollout(mc, tc, lambda t, q: policy(t, q), n_paths, record_paths=True)
    qp = np.asarray(ro(jax.random.PRNGKey(seed))["q_path"]).reshape(-1, mc.d)
    h = mc.lattice_step
    n = tuple(int(round(2 * Q / h)) + 1 for Q in mc.Q)
    i1 = np.clip(np.round((qp[:, 0] + mc.Q[0]) / h), 0, n[0] - 1).astype(int)
    i2 = np.clip(np.round((qp[:, 1] + mc.Q[1]) / h), 0, n[1] - 1).astype(int)
    H = np.zeros(n)
    np.add.at(H, (i1, i2), 1)
    return H / H.sum()
