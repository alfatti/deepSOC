"""Han & E (2016) control network: one feedforward sub-network per time block,
    input (state)  ->  Linear -> BN -> ReLU  ->  Linear -> BN -> ReLU  ->  Linear (control)
with batch normalisation after each hidden linear map and no activation on the output.

All sub-network parameters are stacked along a leading `n_blocks` axis so the whole
stack is a single pytree that can be indexed inside `lax.scan`.
"""
from __future__ import annotations

from typing import Any, Dict, Tuple

import jax
import jax.numpy as jnp
import numpy as np

Params = Dict[str, jnp.ndarray]
BNState = Dict[str, jnp.ndarray]


def init_block(key, n_in: int, n_hidden: int, n_out: int, out_bias: np.ndarray | None = None) -> Params:
    k1, k2, k3 = jax.random.split(key, 3)
    he = lambda k, i, o: jax.random.normal(k, (i, o), jnp.float32) * jnp.sqrt(2.0 / i)
    return {
        "W1": he(k1, n_in, n_hidden), "b1": jnp.zeros(n_hidden),
        "g1": jnp.ones(n_hidden), "be1": jnp.zeros(n_hidden),
        "W2": he(k2, n_hidden, n_hidden), "b2": jnp.zeros(n_hidden),
        "g2": jnp.ones(n_hidden), "be2": jnp.zeros(n_hidden),
        # small output weights so the initial policy is ~ the output bias (warm start)
        "W3": jax.random.normal(k3, (n_hidden, n_out), jnp.float32) * 1e-3,
        "b3": jnp.zeros(n_out) if out_bias is None else jnp.asarray(out_bias, jnp.float32),
    }


def init_bn(n_hidden: int) -> BNState:
    return {"m1": jnp.zeros(n_hidden), "v1": jnp.ones(n_hidden),
            "m2": jnp.zeros(n_hidden), "v2": jnp.ones(n_hidden)}


def init_stack(key, n_blocks: int, n_in: int, n_hidden: int, n_out: int,
               out_bias: np.ndarray | None = None) -> Tuple[Params, BNState]:
    keys = jax.random.split(key, n_blocks)
    params = jax.vmap(lambda k: init_block(k, n_in, n_hidden, n_out, out_bias))(keys)
    bn = jax.tree_util.tree_map(lambda a: jnp.broadcast_to(a, (n_blocks,) + a.shape), init_bn(n_hidden))
    return params, bn


def _bn(h, g, b, m, v, train: bool, eps: float = 1e-5):
    if train:
        mu = h.mean(0)
        var = h.var(0)
    else:
        mu, var = m, v
    out = (h - mu) / jnp.sqrt(var + eps) * g + b
    return out, (mu, var)


def apply_block(p: Params, bn: BNState, x, train: bool):
    """x: (B, n_in) -> (control (B, n_out), batch statistics)."""
    h = x @ p["W1"] + p["b1"]
    h, s1 = _bn(h, p["g1"], p["be1"], bn["m1"], bn["v1"], train)
    h = jax.nn.relu(h)
    h = h @ p["W2"] + p["b2"]
    h, s2 = _bn(h, p["g2"], p["be2"], bn["m2"], bn["v2"], train)
    h = jax.nn.relu(h)
    out = h @ p["W3"] + p["b3"]
    stats = {"m1": s1[0], "v1": s1[1], "m2": s2[0], "v2": s2[1]}
    return out, stats


def select_block(stack, blk):
    return jax.tree_util.tree_map(lambda a: a[blk], stack)


def bn_ema_update(bn: BNState, stats_per_step, block_of_step: np.ndarray, n_blocks: int, momentum: float) -> BNState:
    """Average the per-step batch statistics within each block and EMA-update the running stats."""
    counts = np.bincount(block_of_step, minlength=n_blocks).astype(np.float32)
    seg = lambda a: jax.ops.segment_sum(a, jnp.asarray(block_of_step), num_segments=n_blocks) / jnp.asarray(counts)[:, None]
    new = {k: seg(v) for k, v in stats_per_step.items()}
    return {k: momentum * bn[k] + (1 - momentum) * new[k] for k in bn}
