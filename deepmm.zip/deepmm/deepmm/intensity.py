"""Logistic RFQ intensity and the Model-B Hamiltonian.

For Model B (xi = 0) the Hamiltonian is size-independent:

    H(p) = sup_delta  Lambda(delta) (delta - p),   Lambda(delta) = lam / (1 + exp(alpha + beta delta))

and the optimal quote given the "shadow price" p is the maximiser delta*(p), with
H'(p) = -Lambda(delta*(p)) (envelope theorem).  There is no closed form for the
logistic case, so we solve the first-order condition by safeguarded Newton in
float64 numpy and tabulate (H, delta*) on a fine p-grid for jnp.interp lookups
inside jitted code.
"""
from __future__ import annotations

from dataclasses import dataclass

import jax
import jax.numpy as jnp
import numpy as np

from .config import MarketConfig


# ----------------------------------------------------------------------------- jax side
def fill_prob(delta, mc: MarketConfig):
    """P(client trades | our quote delta), same on both sides and both assets."""
    return jax.nn.sigmoid(-(mc.alpha + mc.beta * delta))


# --------------------------------------------------------------------------- numpy side
def _lam_np(delta, mc):
    s = 1.0 / (1.0 + np.exp(mc.alpha + mc.beta * delta))
    L = mc.lam * s
    L1 = -mc.lam * mc.beta * s * (1 - s)
    L2 = mc.lam * mc.beta**2 * s * (1 - s) * (1 - 2 * s)
    return L, L1, L2


def delta_star_np(p, mc: MarketConfig, n_iter: int = 60) -> np.ndarray:
    """Maximiser of Lambda(delta)(delta - p) for each p (float64, vectorised).

    G(d) = Lambda'(d)(d - p) + Lambda(d).  G(p) = Lambda(p) > 0 and G -> 0- as d -> inf
    through negative values, and the maximiser is unique (log-concavity of the logistic
    intensity), so a bracketed Newton on [p, p + 30/beta] is safe.
    """
    p = np.asarray(p, dtype=np.float64)
    lo = p.copy()
    hi = p + 30.0 / mc.beta
    d = p + 1.0 / mc.beta
    for _ in range(n_iter):
        L, L1, L2 = _lam_np(d, mc)
        g = L1 * (d - p) + L
        dg = L2 * (d - p) + 2.0 * L1
        lo = np.where(g > 0, d, lo)
        hi = np.where(g < 0, d, hi)
        with np.errstate(divide="ignore", invalid="ignore"):
            d_new = d - g / dg
        bad = ~np.isfinite(d_new) | (d_new <= lo) | (d_new >= hi)
        d = np.where(bad, 0.5 * (lo + hi), d_new)
    return d


def hamiltonian_np(p, mc: MarketConfig) -> np.ndarray:
    d = delta_star_np(p, mc)
    L, _, _ = _lam_np(d, mc)
    return L * (d - p)


def hamiltonian_derivs_at(p0: float, mc: MarketConfig):
    """(H(p0), H'(p0), H''(p0)) via the envelope and implicit-function theorems."""
    ds = float(delta_star_np(np.array([p0]), mc)[0])
    L, L1, L2 = _lam_np(ds, mc)
    H0 = L * (ds - p0)
    H1 = -L
    ddelta_dp = L1 / (L2 * (ds - p0) + 2.0 * L1)
    H2 = -L1 * ddelta_dp
    return float(H0), float(H1), float(H2)


@dataclass(frozen=True)
class HamiltonianTable:
    """Tabulated H(p) and delta*(p) for jnp.interp inside jitted code (float32)."""

    p_grid: jnp.ndarray
    H: jnp.ndarray
    dstar: jnp.ndarray

    @staticmethod
    def build(mc: MarketConfig, p_min: float = -6.0, p_max: float = 12.0, n: int = 36001) -> "HamiltonianTable":
        p = np.linspace(p_min, p_max, n)
        ds = delta_star_np(p, mc)
        L, _, _ = _lam_np(ds, mc)
        H = L * (ds - p)
        f32 = lambda a: jnp.asarray(a, dtype=jnp.float32)
        return HamiltonianTable(p_grid=f32(p), H=f32(H), dstar=f32(ds))

    def H_of(self, p):
        return jnp.interp(p, self.p_grid, self.H)

    def dstar_of(self, p):
        return jnp.interp(p, self.p_grid, self.dstar)
