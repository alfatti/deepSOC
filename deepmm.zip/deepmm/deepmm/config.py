"""Configuration for the BEGV two-asset RFQ market-making example (Section 6 of
Bergault, Evangelista, Guéant, Vieira, "Closed-form approximations in multi-asset
market making") solved with the Han & E deep stochastic-control architecture.

Units: prices/quotes in EUR, inventories in number of assets, time in days.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Tuple

import numpy as np


@dataclass(frozen=True)
class MarketConfig:
    """The BEGV example. Model B (risk-adjusted expectation), one tier, no fixed costs."""

    mu: Tuple[float, ...] = (0.1, -0.1)          # EUR / day
    sigma: Tuple[float, ...] = (1.2, 0.6)        # EUR / sqrt(day)
    rho: float = 0.5
    T: float = 7.0                               # days
    gamma: float = 8e-6                          # EUR^-1

    # Logistic RFQ intensity, identical on both assets and both sides:
    #   Lambda(delta) = lam / (1 + exp(alpha + beta * delta))
    lam: float = 30.0                            # RFQs / day per (asset, side)
    alpha: float = 0.7
    beta: float = 30.0                           # EUR^-1

    # 4-point discretisation of the Gamma(4, 4e-4) request-size law used for the grid.
    sizes: Tuple[float, ...] = (6250.0, 12500.0, 18750.0, 25000.0)
    size_probs: Tuple[float, ...] = (0.534, 0.350, 0.097, 0.019)

    Q: Tuple[float, ...] = (75000.0, 300000.0)   # risk limits

    # Quote floor / ceiling used only when *evaluating* policies (the -delta_inf of the paper).
    delta_min: float = -0.5
    delta_max: float = 5.0

    # ---- derived -------------------------------------------------------------
    @property
    def d(self) -> int:
        return len(self.mu)

    @property
    def n_sizes(self) -> int:
        return len(self.sizes)

    @property
    def n_streams(self) -> int:
        # one stream per (asset, side); side 0 = bid (we buy, q up), side 1 = ask (we sell, q down)
        return 2 * self.d

    @property
    def n_controls(self) -> int:
        # control layout: index = asset * (2 * n_sizes) + side * n_sizes + size
        return self.d * 2 * self.n_sizes

    @property
    def Sigma(self) -> np.ndarray:
        s = np.asarray(self.sigma)
        C = np.full((self.d, self.d), self.rho) + (1 - self.rho) * np.eye(self.d)
        return np.outer(s, s) * C

    @property
    def stream_sign(self) -> np.ndarray:
        """Inventory sign per stream: +1 for bid (we buy), -1 for ask."""
        return np.array([+1.0, -1.0] * self.d)

    @property
    def stream_asset(self) -> np.ndarray:
        return np.repeat(np.arange(self.d), 2)

    @property
    def lattice_step(self) -> float:
        """The inventory lattice step used by the finite-difference benchmark."""
        return float(self.sizes[0])


@dataclass(frozen=True)
class TrainConfig:
    """Han & E deep-control training set-up."""

    dt: float = 1.0 / 96.0        # 15-minute steps  ->  672 steps over 7 days
    block_size: int = 4           # consecutive steps sharing one sub-network (4 -> hourly blocks)
    hidden: int = 100             # Han & E use 100 hidden units per layer (execution example)
    max_arrivals: int = 4         # cap on Poisson arrivals per stream per step (P(N>=5) ~ 1e-5)

    batch_size: int = 16384
    n_iters: int = 12000
    lr: float = 3e-4              # peak Adam LR (Han & E use 1e-3 from random init; the warm start needs gentler steps)
    warmup_iters: int = 300       # linear LR warm-up so Adam's first sign-like steps do not destroy the warm start
    lr_decay_at: float = 0.5      # half-way LR drop (x0.1), as in Han & E's energy example
    bn_momentum: float = 0.95

    # straight-through fill relaxation temperature, annealed geometrically
    tau_init: float = 0.10
    tau_final: float = 0.02

    reward_scale: float = 1e-3    # rewards are O(1e3) EUR per step; keep loss O(1)
    warm_start: str = "closedform"  # "closedform" | "random"
    warm_iters: int = 1500        # supervised fit to the closed form; quote precision of the fit is the initial regret floor
    remat: bool = True            # gradient checkpointing across the time scan
    seed: int = 0


def n_steps_for(mc: MarketConfig, tc: TrainConfig) -> int:
    return int(round(mc.T / tc.dt))


def n_blocks_for(mc: MarketConfig, tc: TrainConfig) -> int:
    return -(-n_steps_for(mc, tc) // tc.block_size)
