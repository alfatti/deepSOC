"""Discrete-time simulator of the BEGV RFQ market in the Han & E form
    s_{t+1} = s_t + b_t(s_t, a_t) + xi_{t+1}
with state s_t = q_t (inventory), control a_t = the 16 quotes, and exogenous noise
xi = (Poisson arrival counts, request sizes, fill uniforms) per stream.

Model-B objective (prices integrated out analytically, see README):
    J = E[ sum_t ( sum_{fills} delta z  +  mu'q_t dt  -  gamma/2 q_t' Sigma q_t dt ) ]

Gradient estimator (the part Han & E did not need):
  * immediate reward uses the conditional expectation  N_t * delta * z * p(delta)  -> exact
    pathwise gradient, no fill-draw variance;
  * the inventory transition uses a straight-through fill:  hard 1{u < p(delta)} in the
    forward pass, sigmoid((p(delta) - u)/tau) in the backward pass.  The simulated
    trajectory therefore matches the evaluation dynamics exactly; only the gradient is
    relaxed.
"""
from __future__ import annotations

from typing import Callable, Dict, NamedTuple

import jax
import jax.numpy as jnp
import numpy as np

from .config import MarketConfig, TrainConfig, n_steps_for
from .intensity import fill_prob
from .policy import apply_block, select_block


class StepNoise(NamedTuple):
    n_arr: jnp.ndarray   # (B, S) arrival counts, capped at K
    zidx: jnp.ndarray    # (B, S, K) size index per arrival
    u: jnp.ndarray       # (B, S, K) fill uniforms
    eps: jnp.ndarray     # (B, d) price shocks (used only in evaluation)


def sample_noise(key, B: int, mc: MarketConfig, tc: TrainConfig) -> StepNoise:
    k1, k2, k3, k4 = jax.random.split(key, 4)
    S, K = mc.n_streams, tc.max_arrivals
    n_arr = jnp.minimum(jax.random.poisson(k1, mc.lam * tc.dt, (B, S)), K)
    logp = jnp.log(jnp.asarray(mc.size_probs, jnp.float32))
    zidx = jax.random.categorical(k2, logp, shape=(B, S, K))
    u = jax.random.uniform(k3, (B, S, K), jnp.float32)
    eps = jax.random.normal(k4, (B, mc.d), jnp.float32)
    return StepNoise(n_arr, zidx, u, eps)


def apply_fills(q, delta, noise: StepNoise, mc: MarketConfig, tc: TrainConfig,
                tau: float | None):
    """One step of RFQ arrivals and fills.

    q:      (B, d) inventory at the start of the step
    delta:  (B, n_controls) quotes in the control layout (asset, side, size)
    tau:    straight-through temperature; None -> hard fills only (evaluation)
    Returns q_next, expected reward (conditional on arrivals), realised reward, #fills.
    """
    B = q.shape[0]
    S, K, nz = mc.n_streams, tc.max_arrivals, mc.n_sizes
    sizes = jnp.asarray(mc.sizes, jnp.float32)
    Q = jnp.asarray(mc.Q, jnp.float32)
    sign = mc.stream_sign
    asset = mc.stream_asset

    d = delta.reshape(B, S, nz)
    dsel = jnp.take_along_axis(d, noise.zidx, axis=2)                 # (B, S, K)
    z = sizes[noise.zidx]                                             # (B, S, K)
    arrived = (jnp.arange(K)[None, None, :] < noise.n_arr[..., None]).astype(jnp.float32)
    pf = fill_prob(dsel, mc)
    hard = arrived * (noise.u < pf).astype(jnp.float32)
    if tau is None:
        f = hard
    else:
        soft = arrived * jax.nn.sigmoid((pf - noise.u) / tau)
        f = hard + soft - jax.lax.stop_gradient(soft)                # value = hard, grad = soft

    # sequential risk-limit masking (a fill is rejected if it would breach |q^i| <= Q^i)
    q_hard = q
    dq = jnp.zeros_like(q)
    r_exp = jnp.zeros(B, jnp.float32)
    r_real = jnp.zeros(B, jnp.float32)
    n_fills = jnp.zeros(B, jnp.float32)
    for s in range(S):
        a, sg = int(asset[s]), float(sign[s])
        onehot = jnp.zeros(mc.d, jnp.float32).at[a].set(1.0)
        for k in range(K):
            zk = z[:, s, k]
            ok = (jnp.abs(q_hard[:, a] + sg * zk) <= Q[a] + 1e-3).astype(jnp.float32) * arrived[:, s, k]
            fk = f[:, s, k] * ok
            hk = hard[:, s, k] * ok
            q_hard = q_hard + (sg * zk * hk)[:, None] * onehot[None, :]
            dq = dq + (sg * zk * fk)[:, None] * onehot[None, :]
            r_exp = r_exp + ok * dsel[:, s, k] * zk * pf[:, s, k]
            r_real = r_real + hk * dsel[:, s, k] * zk
            n_fills = n_fills + hk
    return q + dq, r_exp, r_real, n_fills


def block_of_step(mc: MarketConfig, tc: TrainConfig) -> np.ndarray:
    """Step -> sub-network index.  Step 0 (constant input q0 = 0, Han & E skip BN there)
    gets its own sub-network; the remaining steps share weights in blocks of `block_size`."""
    n = n_steps_for(mc, tc)
    b = np.zeros(n, np.int32)
    b[1:] = 1 + (np.arange(n - 1) // tc.block_size)
    return b


def running_reward(q, mc: MarketConfig, dt: float):
    mu = jnp.asarray(mc.mu, jnp.float32)
    Sig = jnp.asarray(mc.Sigma, jnp.float32)
    return (q @ mu - 0.5 * mc.gamma * jnp.einsum("bi,ij,bj->b", q, Sig, q)) * dt


# ------------------------------------------------------------------------------ training
def make_train_loss(mc: MarketConfig, tc: TrainConfig):
    n_steps = n_steps_for(mc, tc)
    bos = jnp.asarray(block_of_step(mc, tc))
    Qn = jnp.asarray(mc.Q, jnp.float32)

    def loss_fn(params, bn, key, tau):
        B = tc.batch_size
        q0 = jnp.zeros((B, mc.d), jnp.float32)

        def step(carry, t):
            q, acc = carry
            p = select_block(params, bos[t])
            b = select_block(bn, bos[t])
            delta, stats = apply_block(p, b, q / Qn, train=True)
            noise = sample_noise(jax.random.fold_in(key, t), B, mc, tc)
            q_next, r_exp, _, _ = apply_fills(q, delta, noise, mc, tc, tau)
            acc = acc + r_exp + running_reward(q, mc, tc.dt)
            return (q_next, acc), stats

        if tc.remat:
            step = jax.checkpoint(step)
        (_, acc), stats = jax.lax.scan(step, (q0, jnp.zeros(B, jnp.float32)), jnp.arange(n_steps))
        return -tc.reward_scale * acc.mean(), stats

    return loss_fn


def nn_policy_fn(mc: MarketConfig, tc: TrainConfig) -> Callable:
    """Evaluation-mode policy with explicit parameters: (t_idx, q, params, bn) -> delta.
    Use this form inside jitted rollouts so that they compile once and are re-used across
    parameter updates.  NOTE: the step-0 sub-network only ever sees q0 = 0 (its BN
    statistics are degenerate by design); evaluate the policy at t_idx >= 1 for q != 0."""
    bos = jnp.asarray(block_of_step(mc, tc))
    Qn = jnp.asarray(mc.Q, jnp.float32)

    def pol(t_idx, q, params, bn):
        p = select_block(params, bos[t_idx])
        b = select_block(bn, bos[t_idx])
        out, _ = apply_block(p, b, q / Qn, train=False)
        return out

    return pol


def nn_policy(params, bn, mc: MarketConfig, tc: TrainConfig) -> Callable:
    """Evaluation-mode policy with the parameters closed over: (t_idx, q) -> delta."""
    f = nn_policy_fn(mc, tc)
    return lambda t_idx, q: f(t_idx, q, params, bn)


# ---------------------------------------------------------------------------- evaluation
def make_eval_rollout(mc: MarketConfig, tc: TrainConfig, policy: Callable, n_paths: int,
                      record_paths: bool = False):
    """Hard-fill simulation with prices.  Returns per-path PnL statistics.

    policy: (t_idx, q, *pol_args) -> delta (B, n_controls); the returned jitted function is
    rollout(key, *pol_args), so a network policy is evaluated as rollout(key, params, bn)
    without recompiling.  Quotes are clipped to [delta_min, delta_max].
    PnL decomposition (q0 = 0):   X_T + q_T S_T  =  sum fills delta z  +  sum_t q_t' dS_t.
    """
    n_steps = n_steps_for(mc, tc)
    L = jnp.asarray(np.linalg.cholesky(mc.Sigma), jnp.float32)
    mu = jnp.asarray(mc.mu, jnp.float32)
    sqdt = float(np.sqrt(tc.dt))

    def rollout(key, *pol_args):
        B = n_paths
        q0 = jnp.zeros((B, mc.d), jnp.float32)
        z0 = jnp.zeros(B, jnp.float32)

        def step(carry, t):
            q, spread, mtm, risk, nf, qmax = carry
            delta = jnp.clip(policy(t, q, *pol_args), mc.delta_min, mc.delta_max)
            noise = sample_noise(jax.random.fold_in(key, t), B, mc, tc)
            q_next, _, r_real, k = apply_fills(q, delta, noise, mc, tc, None)
            dS = mu * tc.dt + (noise.eps @ L.T) * sqdt
            mtm = mtm + (q * dS).sum(-1)
            risk = risk + 0.5 * mc.gamma * jnp.einsum("bi,ij,bj->b", q, jnp.asarray(mc.Sigma, jnp.float32), q) * tc.dt
            qmax = jnp.maximum(qmax, jnp.abs(q_next))
            out = q_next if record_paths else None
            return (q_next, spread + r_real, mtm, risk, nf + k, qmax), out

        (qT, spread, mtm, risk, nf, qmax), qpath = jax.lax.scan(
            step, (q0, z0, z0, z0, z0, jnp.zeros((B, mc.d))), jnp.arange(n_steps))
        pnl = spread + mtm
        res = {"pnl": pnl, "objective": pnl - risk, "spread_pnl": spread, "mtm_pnl": mtm,
               "risk_penalty": risk, "n_fills": nf, "q_T": qT, "q_absmax": qmax}
        if record_paths:
            res["q_path"] = qpath
        return res

    return jax.jit(rollout)


def summarize(res: Dict[str, jnp.ndarray], name: str = "") -> str:
    pnl = np.asarray(res["pnl"]); obj = np.asarray(res["objective"])
    n = pnl.size
    return (f"{name:>12s}  E[PnL]={pnl.mean():9.0f} ± {pnl.std()/np.sqrt(n):5.0f}  sd={pnl.std():8.0f}  "
            f"E[obj]={obj.mean():9.0f} ± {obj.std()/np.sqrt(n):5.0f}  "
            f"spread={np.asarray(res['spread_pnl']).mean():8.0f}  fills/path={np.asarray(res['n_fills']).mean():6.1f}  "
            f"max|q|=({np.asarray(res['q_absmax'])[:,0].max():.0f},{np.asarray(res['q_absmax'])[:,1].max():.0f})")
