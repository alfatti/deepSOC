"""Han & E training loop for the RFQ market-making control problem."""
from __future__ import annotations

import pickle
import time
from dataclasses import asdict
from pathlib import Path
from typing import Callable, Optional

import jax
import jax.numpy as jnp
import numpy as np
import optax

from .closedform import ClosedForm
from .config import MarketConfig, TrainConfig, n_steps_for
from .policy import apply_block, bn_ema_update, init_stack, select_block
from .sim import block_of_step, make_eval_rollout, make_train_loss, nn_policy_fn, summarize


def _n_blocks(mc, tc):
    return int(block_of_step(mc, tc).max()) + 1


def warm_start_closedform(params, bn, cf: ClosedForm, mc: MarketConfig, tc: TrainConfig, key, log=print,
                          n_paths: int | None = None):
    """Supervised pre-training of every sub-network onto the closed-form asymptotic quotes
    (BEGV's suggested use of the proxy as a starting policy).

    Each block is fitted on the inventories its *own* time steps visit under the closed-form
    policy, so that the batch-normalisation statistics seen in training-mode match the
    on-policy state distribution (fitting on a uniform cloud over the risk box breaks the
    train-mode network, because BN rescales by batch statistics).  All blocks are fitted
    simultaneously with a vmapped Adam."""
    n_blocks = _n_blocks(mc, tc)
    n_steps = n_steps_for(mc, tc)
    bos = block_of_step(mc, tc)
    Qn = jnp.asarray(mc.Q, jnp.float32)
    n_paths = n_paths or min(tc.batch_size, 4096)

    # 1. on-policy states under the (finite-horizon) closed-form policy
    cfp = cf.policy_finite_horizon(tc.dt)
    ro = make_eval_rollout(mc, tc, lambda t, q: cfp(t, q), n_paths, record_paths=True)
    qpath = np.asarray(ro(key)["q_path"])                      # (n_steps, B, d): q_{t+1}
    q_at = np.concatenate([np.zeros((1, n_paths, mc.d), np.float32), qpath[:-1]], 0)  # q_t, t = 0..n-1
    idx = np.zeros((n_blocks, tc.block_size), np.int64)          # step indices per block (block 0: step 0)
    for j in range(n_blocks):
        steps = np.where(bos == j)[0]
        idx[j] = np.resize(steps, tc.block_size)
    Xs = jnp.asarray(q_at[idx].reshape(n_blocks, -1, mc.d))      # (n_blocks, block_size*B, d)
    # targets: finite-horizon closed-form quotes (Prop. 5) at each block's mean time, so the
    # last-day blocks start with the correct boundary layer instead of the ergodic quotes
    t_blk = jnp.asarray(tc.dt * idx.mean(1), jnp.float32)
    Ys = jax.vmap(cf.quotes_t)(t_blk, Xs)                        # (n_blocks, block_size*B, n_controls)

    # 2. vmapped supervised fit (cosine-decayed Adam: the precision of this fit sets the initial regret)
    opt = optax.adam(optax.cosine_decay_schedule(3e-3, tc.warm_iters, alpha=3e-3))
    state = opt.init(params)

    def loss_one(p, b, x, y):
        out, stats = apply_block(p, b, x / Qn, train=True)
        return jnp.mean((out - y) ** 2), stats

    vloss = jax.vmap(loss_one)

    @jax.jit
    def fit_step(params, bn, state, k):
        nb = Xs.shape[1]
        sub = jax.random.choice(k, nb, (min(nb, 8192),), replace=False)
        x, y = Xs[:, sub], Ys[:, sub]
        def total(p, b):
            l, stats = vloss(p, b, x, y)
            return l.sum(), (l, stats)
        (_, (l, stats)), g = jax.value_and_grad(total, has_aux=True)(params, bn)
        upd, state = opt.update(g, state, params)
        params = optax.apply_updates(params, upd)
        bn = {kname: 0.9 * bn[kname] + 0.1 * stats[kname] for kname in bn}
        return params, bn, state, l

    for i in range(tc.warm_iters):
        key, k = jax.random.split(key)
        params, bn, state, l = fit_step(params, bn, state, k)
    l = np.asarray(l)
    log(f"warm start (finite-horizon closed form): {n_blocks} blocks fitted on {Xs.shape[1]} on-policy states each; "
        f"mse block0={l[0]:.2e} mean={l.mean():.2e} max={l.max():.2e}")
    return params, bn


def train(mc: MarketConfig, tc: TrainConfig, out_dir: str | Path = "runs/default",
          log: Callable = print, val_paths: int = 8192, val_every: int = 500,
          fd=None, table=None) -> dict:
    """Han & E training.  If the finite-difference solution `fd` (and the Hamiltonian `table`)
    are given, validation also reports the one-step Bellman regret of the network w.r.t. the
    FD value function and the best checkpoint is selected on that (far more discriminating
    than the PnL objective: FD ~0.4 EUR, closed form ~70 EUR, vs an 87k PnL sd)."""
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    key = jax.random.PRNGKey(tc.seed)
    n_blocks = _n_blocks(mc, tc)
    n_steps = n_steps_for(mc, tc)
    bos = block_of_step(mc, tc)
    cf = ClosedForm.build(mc)

    out_bias = np.asarray(cf.quotes(jnp.zeros(mc.d)))
    key, k_init, k_warm = jax.random.split(key, 3)
    params, bn = init_stack(k_init, n_blocks, mc.d, tc.hidden, mc.n_controls, out_bias)
    if tc.warm_start == "closedform":
        params, bn = warm_start_closedform(params, bn, cf, mc, tc, k_warm, log)

    sched = optax.join_schedules(
        [optax.linear_schedule(0.0, tc.lr, tc.warmup_iters),
         optax.piecewise_constant_schedule(tc.lr, {int(tc.lr_decay_at * tc.n_iters) - tc.warmup_iters: 0.1})],
        [tc.warmup_iters])
    opt = optax.chain(optax.clip_by_global_norm(1.0), optax.adam(sched))
    opt_state = opt.init(params)
    loss_fn = make_train_loss(mc, tc)

    @jax.jit
    def update(params, bn, opt_state, key, tau):
        (l, stats), g = jax.value_and_grad(loss_fn, has_aux=True)(params, bn, key, tau)
        upd, opt_state = opt.update(g, opt_state, params)
        params = optax.apply_updates(params, upd)
        bn = bn_ema_update(bn, stats, bos, n_blocks, tc.bn_momentum)
        return params, bn, opt_state, l

    tau_of = lambda i: tc.tau_init * (tc.tau_final / tc.tau_init) ** (i / max(tc.n_iters - 1, 1))
    val_key = jax.random.PRNGKey(12345)
    history = {"iter": [], "loss": [], "val_iter": [], "val_obj": [], "val_pnl": [], "val_regret": [], "tau": [], "time": []}
    best = (-np.inf, None, None)
    t0 = time.time()

    pol = nn_policy_fn(mc, tc)
    val_rollout = make_eval_rollout(mc, tc, pol, val_paths)          # compiled once, re-used
    regret_rollout = None
    if fd is not None:
        from .diagnostics import make_regret_rollout
        regret_rollout = make_regret_rollout(mc, tc, pol, pol, fd, table, min(val_paths, 4096))

    for i in range(tc.n_iters + 1):
        if i % val_every == 0:
            res = val_rollout(val_key, params, bn)
            obj = float(np.mean(np.asarray(res["objective"])))
            pnl = float(np.mean(np.asarray(res["pnl"])))
            regret = None
            if regret_rollout is not None:
                s = np.asarray(regret_rollout(val_key, params, bn))
                regret = float(s[:, 5].sum() * tc.dt)
            history["val_iter"].append(i); history["val_obj"].append(obj); history["val_pnl"].append(pnl)
            history["val_regret"].append(regret)
            extra = f"  regret={regret:8.1f} EUR" if regret is not None else ""
            log(f"[{i:6d}] {summarize(res, 'NN(val)')}{extra}  tau={tau_of(i):.3f}  {time.time()-t0:7.0f}s")
            score = -regret if regret is not None else obj
            if score > best[0]:
                best = (score, jax.tree_util.tree_map(np.asarray, params), jax.tree_util.tree_map(np.asarray, bn))
                with open(out_dir / "best.pkl", "wb") as f:
                    pickle.dump({"params": best[1], "bn": best[2], "val_obj": obj, "val_regret": regret, "iter": i,
                                 "market": asdict(mc), "train": asdict(tc)}, f)
        if i == tc.n_iters:
            break
        key, k = jax.random.split(key)
        params, bn, opt_state, l = update(params, bn, opt_state, k, tau_of(i))
        if i % 50 == 0:
            history["iter"].append(i); history["loss"].append(float(l)); history["tau"].append(tau_of(i))
            history["time"].append(time.time() - t0)
        if i % 100 == 0:
            log(f"[{i:6d}] loss={float(l):.5f}  (objective ~ {-float(l)/tc.reward_scale:9.0f})")

    with open(out_dir / "final.pkl", "wb") as f:
        pickle.dump({"params": jax.tree_util.tree_map(np.asarray, params), "bn": jax.tree_util.tree_map(np.asarray, bn),
                     "history": history, "market": asdict(mc), "train": asdict(tc)}, f)
    return {"params": params, "bn": bn, "best_params": best[1], "best_bn": best[2], "history": history, "closedform": cf}
