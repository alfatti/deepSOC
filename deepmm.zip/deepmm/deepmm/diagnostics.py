"""Quality-of-fit and behavioural diagnostics for a learned quoting policy.

All metrics are computed *on the states the policy actually visits* (q0 = 0, Han & E) so
that they measure the policy where it matters and where it was trained.  Everything the
notebook plots and the behavioural tests assert is computed here.

Metrics
-------
policy_gap_on_paths   per-time-step distribution (quantiles) of |delta_pol(t, q_t) - delta_fd(t, q_t)|
                      over paths and feasible controls -> time-indexed box plots.
regret_on_paths       one-step Bellman regret rate (EUR/day) of the policy w.r.t. the FD value
                      function:  sum_{i,side,k} p_k z_k [ H(p) - Lambda(delta)(delta - p) ] >= 0,
                      with p the FD shadow price at (t, q_t).  Its time integral is the
                      first-order value loss of the policy relative to the optimum.
visited_region        lattice mask of states visited with frequency above a threshold.
behavioural_checks    monotonicity in own/cross inventory and size, drift asymmetry,
                      stationarity, terminal boundary layer, improvement over closed form.
"""
from __future__ import annotations

from typing import Callable, Dict

import jax
import jax.numpy as jnp
import numpy as np

from .config import MarketConfig, TrainConfig, n_steps_for
from .fd import FDSolution
from .intensity import HamiltonianTable, fill_prob
from .sim import apply_fills, sample_noise

QUANTILES = np.array([0.05, 0.25, 0.5, 0.75, 0.95])


def _feasible_mask(q, mc: MarketConfig):
    """(B, n_controls) feasibility of each quote at inventory q (bid: q + z <= Q, ask: q - z >= -Q)."""
    z = jnp.asarray(mc.sizes, jnp.float32)
    Q = jnp.asarray(mc.Q, jnp.float32)
    bid = (q[:, :, None] + z[None, None, :] <= Q[None, :, None] + 1e-3)        # (B, d, nz)
    ask = (q[:, :, None] - z[None, None, :] >= -Q[None, :, None] - 1e-3)
    return jnp.stack([bid, ask], 2).reshape(q.shape[0], mc.n_controls)


def _lattice_gather(fd: FDSolution, arr, t_idx, q):
    i1, i2 = fd.lattice.index(q)
    return arr[t_idx, i1, i2]


def make_gap_rollout(mc: MarketConfig, tc: TrainConfig, driver: Callable, policy: Callable, fd: FDSolution,
                     n_paths: int = 4096) -> Callable:
    """Jitted: rollout(key, *pol_args) -> per-step summary (n_steps, 7) of |policy - fd| on visited
    states.  `driver` and `policy` both receive *pol_args (pass the network for both, or the
    network as driver and a parameter-free policy that ignores the extra args)."""
    n_steps = n_steps_for(mc, tc)
    fd_q = jnp.asarray(fd.quotes)
    qs = jnp.asarray(QUANTILES)

    def rollout(key, *pol_args):
        q0 = jnp.zeros((n_paths, mc.d), jnp.float32)

        def step(q, t):
            d_pol = jnp.clip(policy(t, q, *pol_args), mc.delta_min, mc.delta_max)
            d_fd = _lattice_gather(fd, fd_q, t, q)
            m = _feasible_mask(q, mc)
            diff = jnp.where(m, jnp.abs(d_pol - d_fd), jnp.nan)
            summary = jnp.concatenate([jnp.nanquantile(diff, qs), jnp.nanmean(diff)[None], jnp.nanmax(diff)[None]])
            noise = sample_noise(jax.random.fold_in(key, t), n_paths, mc, tc)
            d_drv = jnp.clip(driver(t, q, *pol_args), mc.delta_min, mc.delta_max)
            q_next, _, _, _ = apply_fills(q, d_drv, noise, mc, tc, None)
            return q_next, summary

        _, s = jax.lax.scan(step, q0, jnp.arange(n_steps))
        return s

    return jax.jit(rollout)


def _unpack(s, tc, n_steps):
    s = np.asarray(s)
    return {"t": tc.dt * np.arange(n_steps), "quantiles": s[:, :5], "mean": s[:, 5], "max": s[:, 6]}


def policy_gap_on_paths(mc, tc, driver, policy, fd, n_paths=4096, seed=7, pol_args=()):
    s = make_gap_rollout(mc, tc, driver, policy, fd, n_paths)(jax.random.PRNGKey(seed), *pol_args)
    return _unpack(s, tc, n_steps_for(mc, tc))


def make_regret_rollout(mc: MarketConfig, tc: TrainConfig, driver: Callable, policy: Callable, fd: FDSolution,
                        table: HamiltonianTable, n_paths: int = 4096) -> Callable:
    """Jitted: rollout(key, *pol_args) -> per-step summary (n_steps, 7) of the one-step Bellman
    regret rate (EUR/day) of `policy` along `driver`'s trajectories."""
    n_steps = n_steps_for(mc, tc)
    shadow = jnp.asarray(fd.shadow)
    z = jnp.tile(jnp.repeat(jnp.asarray(mc.sizes, jnp.float32)[None], 2, 0).reshape(-1), mc.d)     # (16,)
    pk = jnp.tile(jnp.repeat(jnp.asarray(mc.size_probs, jnp.float32)[None], 2, 0).reshape(-1), mc.d)
    qs = jnp.asarray(QUANTILES)

    def rollout(key, *pol_args):
        q0 = jnp.zeros((n_paths, mc.d), jnp.float32)

        def step(q, t):
            d_pol = jnp.clip(policy(t, q, *pol_args), mc.delta_min, mc.delta_max)
            p = _lattice_gather(fd, shadow, t, q)                                   # (B, 16)
            m = _feasible_mask(q, mc).astype(jnp.float32)
            val = mc.lam * fill_prob(d_pol, mc) * (d_pol - p)                      # Lambda(delta)(delta - p)
            reg = (pk * z * (table.H_of(p) - val) * m).sum(-1)                     # (B,) EUR/day
            summary = jnp.concatenate([jnp.quantile(reg, qs), reg.mean()[None], reg.max()[None]])
            noise = sample_noise(jax.random.fold_in(key, t), n_paths, mc, tc)
            d_drv = jnp.clip(driver(t, q, *pol_args), mc.delta_min, mc.delta_max)
            q_next, _, _, _ = apply_fills(q, d_drv, noise, mc, tc, None)
            return q_next, summary

        _, s = jax.lax.scan(step, q0, jnp.arange(n_steps))
        return s

    return jax.jit(rollout)


def regret_on_paths(mc, tc, driver, policy, fd, table, n_paths=4096, seed=7, pol_args=()):
    s = make_regret_rollout(mc, tc, driver, policy, fd, table, n_paths)(jax.random.PRNGKey(seed), *pol_args)
    out = _unpack(s, tc, n_steps_for(mc, tc))
    out["integrated_EUR"] = float(out["mean"].sum() * tc.dt)
    return out


def ignore_args(policy: Callable) -> Callable:
    """Wrap a parameter-free (t, q) policy so it accepts and ignores *pol_args."""
    return lambda t, q, *a: policy(t, q)


def visited_region(vis: np.ndarray, threshold: float = 1e-4) -> np.ndarray:
    return vis > threshold


def _lay(a, mc):
    return np.asarray(a).reshape(a.shape[:-1] + (mc.d, 2, mc.n_sizes))


def behavioural_checks(mc: MarketConfig, tc: TrainConfig, policy: Callable, fd: FDSolution, cf_policy: Callable,
                       region: np.ndarray, gap_nn: Dict, gap_cf: Dict, reg_nn: Dict, reg_cf: Dict) -> Dict[str, dict]:
    """Returns {name: {"value": ..., "threshold": ..., "pass": bool, "note": str}}."""
    lat = fd.lattice
    n_steps = n_steps_for(mc, tc)
    q1g, q2g = np.meshgrid(lat.q1, lat.q2, indexing="ij")
    Q = np.stack([q1g, q2g], -1).reshape(-1, mc.d).astype(np.float32)
    R = region.reshape(-1)
    t_mid = n_steps // 2
    D = _lay(np.asarray(policy(t_mid, jnp.asarray(Q))), mc).reshape(*lat.n, mc.d, 2, mc.n_sizes)
    F = fd.quotes[t_mid].reshape(*lat.n, mc.d, 2, mc.n_sizes)
    feas = fd.feasible.reshape(*lat.n, mc.d, 2, mc.n_sizes)
    reg2 = region[:, :, None, None, None] & feas
    out = {}

    def mono(diffs, mask, name, note, tol_cents=0.5, max_viol=0.02):
        d = diffs[mask]
        viol = float(np.mean(d < -tol_cents / 100)) if d.size else 0.0
        out[name] = {"value": viol, "threshold": max_viol, "pass": viol <= max_viol, "note": note}

    # 1. own-inventory monotonicity: bid_i increasing in q_i, ask_i decreasing in q_i
    for i, ax in ((0, 0), (1, 1)):
        for side, sgn in ((0, +1), (1, -1)):
            dd = sgn * np.diff(D[..., i, side, :], axis=ax)
            mm = (reg2[..., i, side, :] & np.roll(reg2[..., i, side, :], -1, axis=ax))
            mm = np.delete(mm, -1, axis=ax)
            mono(dd, mm, f"own_mono_asset{i+1}_{'bid' if side == 0 else 'ask'}",
                 "fraction of adjacent visited lattice pairs where the quote moves the wrong way (>0.5c)")
    # 2. cross-asset monotonicity (rho > 0): bid_i increasing in q_j, ask_i decreasing in q_j
    for i, ax in ((0, 1), (1, 0)):
        for side, sgn in ((0, +1), (1, -1)):
            dd = sgn * np.diff(D[..., i, side, :], axis=ax)
            mm = (reg2[..., i, side, :] & np.roll(reg2[..., i, side, :], -1, axis=ax))
            mm = np.delete(mm, -1, axis=ax)
            mono(dd, mm, f"cross_mono_asset{i+1}_{'bid' if side == 0 else 'ask'}",
                 "positive correlation: inventory in the other asset should move the quote the same way")
    # 3. size ordering agrees with FD where the FD ordering is material (> 0.2 cents)
    dn = np.diff(D, axis=-1); df = np.diff(F, axis=-1)
    mm = reg2[..., :-1] & reg2[..., 1:] & (np.abs(df) > 0.002)
    agree = float(np.mean((np.sign(dn) == np.sign(df))[mm])) if mm.any() else 1.0
    out["size_ordering_agrees_with_fd"] = {"value": agree, "threshold": 0.9, "pass": agree >= 0.9,
                                           "note": "fraction of visited states where the size ordering matches the FD optimum"}
    # 4. drift asymmetry at q = 0: mu1 > 0 -> asset-1 bid tighter than ask; mu2 < 0 -> the opposite
    c = (lat.n[0] // 2, lat.n[1] // 2)
    d0 = D[c]
    a1 = float(np.mean(d0[0, 1] - d0[0, 0])); a2 = float(np.mean(d0[1, 0] - d0[1, 1]))
    out["drift_asymmetry_asset1_ask_minus_bid"] = {"value": a1, "threshold": 0.0, "pass": a1 > 0, "note": "EUR, should be > 0 (mu1 > 0)"}
    out["drift_asymmetry_asset2_bid_minus_ask"] = {"value": a2, "threshold": 0.0, "pass": a2 > 0, "note": "EUR, should be > 0 (mu2 < 0)"}
    # 5. stationarity: quotes at visited states change by < 1 cent between t = 2 days and t = T - 3 days.
    #    Both times are in the ergodic regime (the FD optimum moves ~9 cents inside the last day and
    #    0.5 c at T-2d) and both sub-networks have seen the whole visited region -- with q0 = 0 fixed,
    #    the first hours' sub-networks only ever see a small neighbourhood of zero.
    t_early = int(round(2.0 / tc.dt)); t_late = int(round((mc.T - 3.0) / tc.dt))
    Qv = jnp.asarray(Q[R])
    d_early = np.asarray(policy(t_early, Qv)); d_late = np.asarray(policy(t_late, Qv))
    fv = fd.feasible.reshape(-1, mc.n_controls)[R]
    stat = float(np.quantile(np.abs(d_early - d_late)[fv], 0.99))
    out["stationarity_p99_change_2d_to_T-3d"] = {"value": stat, "threshold": 0.01, "pass": stat < 0.01, "note": "EUR (99th pct over visited feasible quotes)"}
    # 6. terminal boundary layer: last-step quotes close to the FD last-step quotes at q = 0
    dT = np.asarray(policy(n_steps - 1, jnp.zeros((1, mc.d), jnp.float32)))[0]
    fT = fd.quotes[n_steps - 1, c[0], c[1]]
    bl = float(np.max(np.abs(dT - fT)))
    out["terminal_layer_max_err_at_q0"] = {"value": bl, "threshold": 0.02, "pass": bl < 0.02, "note": "EUR, |delta_nn - delta_fd| at t = T - dt, q = 0 (boundary layer present)"}
    # 7. fit quality on visited states: NN median gap vs closed-form median gap (time-averaged)
    g_nn = float(np.mean(gap_nn["quantiles"][:, 2])); g_cf = float(np.mean(gap_cf["quantiles"][:, 2]))
    out["median_gap_nn_vs_cf"] = {"value": g_nn, "threshold": g_cf, "pass": g_nn <= g_cf,
                                  "note": f"EUR, time-averaged median |delta - delta_fd| on visited states; closed form = {g_cf:.4f}"}
    g95_nn = float(np.mean(gap_nn["quantiles"][:, 4])); g95_cf = float(np.mean(gap_cf["quantiles"][:, 4]))
    out["p95_gap_nn_vs_cf"] = {"value": g95_nn, "threshold": g95_cf, "pass": g95_nn <= g95_cf,
                               "note": f"EUR, time-averaged 95th pct; closed form = {g95_cf:.4f}"}
    # 8. Bellman regret: integrated first-order value loss vs closed form
    out["integrated_regret_nn_vs_cf"] = {"value": reg_nn["integrated_EUR"], "threshold": reg_cf["integrated_EUR"],
                                         "pass": reg_nn["integrated_EUR"] <= reg_cf["integrated_EUR"],
                                         "note": f"EUR over the horizon (first-order value loss); closed form = {reg_cf['integrated_EUR']:.0f}"}
    return out


def checks_table(checks: Dict[str, dict]) -> str:
    lines = [f"{'check':45s} {'value':>12s} {'threshold':>12s}  pass", "-" * 80]
    for k, v in checks.items():
        lines.append(f"{k:45s} {v['value']:12.4f} {v['threshold']:12.4f}  {'ok' if v['pass'] else 'FAIL'}")
    return "\n".join(lines)
