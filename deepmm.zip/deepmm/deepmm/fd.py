"""Finite-difference benchmark: solve the Hamilton-Jacobi equation (21) of BEGV on the
inventory lattice  q^i in {-Q^i, ..., Q^i} step 6250  (25 x 97 states), Model B,
one tier, no fixed costs, 4-point size law.

    0 = d_t theta + mu'q - gamma/2 q'Sigma q
        + sum_i sum_k p_k [ 1{q^i + z_k <= Q^i} z_k H((theta(q) - theta(q + z_k e_i)) / z_k)
                          + 1{q^i - z_k >= -Q^i} z_k H((theta(q) - theta(q - z_k e_i)) / z_k) ]
    theta(T, q) = 0.

We integrate backward with an explicit Euler scheme.  The scheme is monotone provided
dt * sum_{streams,sizes} p_k Lambda_max <= 1, i.e. dt <= 1/(2 d lam) = 1/120 day here; we
use dt = 1/1920 by default which is well inside that and cheap on the lattice.  The
paper used an implicit scheme with 101 time points; the asymptotic quotes agree.

Optimal quotes at time t for (asset i, side, size k) are delta*(p) with the finite
difference p above.  The policy is stored at the training-time grid (every `save_every`
FD steps) so the FD policy can be simulated with the same simulator as the network.
"""
from __future__ import annotations

from dataclasses import dataclass

import jax
import jax.numpy as jnp
import numpy as np

from .config import MarketConfig
from .intensity import HamiltonianTable


@dataclass(frozen=True)
class Lattice:
    step: float
    n: tuple           # (25, 97)
    q1: np.ndarray
    q2: np.ndarray

    @staticmethod
    def build(mc: MarketConfig) -> "Lattice":
        h = mc.lattice_step
        for z in mc.sizes:
            assert abs(z / h - round(z / h)) < 1e-9, "sizes must be lattice multiples"
        for Q in mc.Q:
            assert abs(Q / h - round(Q / h)) < 1e-9, "risk limits must be lattice multiples"
        n = tuple(int(round(2 * Q / h)) + 1 for Q in mc.Q)
        q1 = -mc.Q[0] + h * np.arange(n[0])
        q2 = -mc.Q[1] + h * np.arange(n[1])
        return Lattice(step=h, n=n, q1=q1, q2=q2)

    def index(self, q):
        """Lattice indices of inventories q (..., 2) -> (i1, i2), clipped."""
        h = self.step
        i1 = jnp.clip(jnp.round((q[..., 0] + (self.n[0] - 1) / 2 * h) / h), 0, self.n[0] - 1).astype(jnp.int32)
        i2 = jnp.clip(jnp.round((q[..., 1] + (self.n[1] - 1) / 2 * h) / h), 0, self.n[1] - 1).astype(jnp.int32)
        return i1, i2


@dataclass(frozen=True)
class FDSolution:
    lattice: Lattice
    t_policy: np.ndarray      # times at which the policy is stored, shape (n_policy,)
    theta: np.ndarray         # (n_policy, 25, 97)
    quotes: np.ndarray        # (n_policy, 25, 97, n_controls), clipped to [delta_min, delta_max]
    shadow: np.ndarray        # (n_policy, 25, 97, n_controls) shadow prices p = (theta(q) - theta(q +/- z e_i)) / z
    feasible: np.ndarray      # (25, 97, n_controls) bool: trade would not breach the risk limit

    def policy(self):
        """(t_index, q) -> delta on the lattice, usable by the simulator."""
        quotes = jnp.asarray(self.quotes)
        lat = self.lattice

        def pol(t_idx, q):
            i1, i2 = lat.index(q)
            return quotes[t_idx, i1, i2]

        return pol


def _rhs_fn(mc: MarketConfig, lat: Lattice, table: HamiltonianTable):
    sizes = np.asarray(mc.sizes)
    probs = np.asarray(mc.size_probs)
    shifts = [int(round(z / lat.step)) for z in sizes]
    Q1, Q2 = lat.q1, lat.q2
    q1g, q2g = np.meshgrid(Q1, Q2, indexing="ij")
    qvec = np.stack([q1g, q2g], -1)                      # (25, 97, 2)
    Sig = mc.Sigma
    running = qvec @ np.asarray(mc.mu) - 0.5 * mc.gamma * np.einsum("abi,ij,abj->ab", qvec, Sig, qvec)
    running = jnp.asarray(running, jnp.float32)
    n1, n2 = lat.n
    pad = max(shifts)

    def rhs(theta):
        # theta: (n1, n2). Pad with edge values (masked anyway).
        tp = jnp.pad(theta, pad, mode="edge")
        acc = running
        quotes = []
        for i, (n, ax) in enumerate(((n1, 0), (n2, 1))):
            for k, (m, z, pk) in enumerate(zip(shifts, sizes, probs)):
                idx = np.arange(n)
                # up: q + z e_i allowed if idx + m <= n-1
                up_ok = jnp.asarray((idx + m <= n - 1).astype(np.float32))
                dn_ok = jnp.asarray((idx - m >= 0).astype(np.float32))
                if ax == 0:
                    th_up = tp[pad + m: pad + m + n1, pad: pad + n2]
                    th_dn = tp[pad - m: pad - m + n1, pad: pad + n2]
                    up_ok, dn_ok = up_ok[:, None], dn_ok[:, None]
                else:
                    th_up = tp[pad: pad + n1, pad + m: pad + m + n2]
                    th_dn = tp[pad: pad + n1, pad - m: pad - m + n2]
                    up_ok, dn_ok = up_ok[None, :], dn_ok[None, :]
                p_up = (theta - th_up) / z     # bid (we buy, q -> q + z e_i)
                p_dn = (theta - th_dn) / z     # ask (we sell, q -> q - z e_i)
                acc = acc + pk * z * (up_ok * table.H_of(p_up) + dn_ok * table.H_of(p_dn))
                quotes.append((i, 0, k, p_up, up_ok))
                quotes.append((i, 1, k, p_dn, dn_ok))
        return acc, quotes

    return rhs


def solve_fd(mc: MarketConfig, table: HamiltonianTable, dt_policy: float, fd_substeps: int = 20) -> FDSolution:
    """Backward explicit Euler.  Policy stored every dt_policy (= training dt), FD step
    dt_policy / fd_substeps (default 1/1920 day for dt_policy = 1/96)."""
    lat = Lattice.build(mc)
    rhs = _rhs_fn(mc, lat, table)
    n_policy = int(round(mc.T / dt_policy))
    dt_fd = dt_policy / fd_substeps
    lam_max = mc.lam / (1 + np.exp(mc.alpha + mc.beta * mc.delta_min))
    cfl = dt_fd * 2 * mc.d * lam_max
    assert cfl <= 1.0, f"explicit Euler not monotone: dt*2*d*Lambda_max = {cfl:.3f} > 1"

    def _to_controls(out, shape):
        return jnp.transpose(out.reshape(mc.n_controls, *shape), (1, 2, 0))

    def quotes_of(theta):
        _, qs = rhs(theta)
        out = jnp.zeros((mc.d, 2, mc.n_sizes) + theta.shape, jnp.float32)
        for (i, s, k, p, ok) in qs:
            d = jnp.clip(table.dstar_of(p), mc.delta_min, mc.delta_max)
            # states where the trade would breach the risk limit: no quote (fills are masked anyway)
            d = jnp.where(ok * jnp.ones_like(d) > 0, d, mc.delta_max)
            out = out.at[i, s, k].set(d)
        return _to_controls(out, theta.shape)

    def shadow_of(theta):
        _, qs = rhs(theta)
        out = jnp.zeros((mc.d, 2, mc.n_sizes) + theta.shape, jnp.float32)
        for (i, s, k, p, ok) in qs:
            out = out.at[i, s, k].set(jnp.where(ok * jnp.ones_like(p) > 0, p, 0.0))
        return _to_controls(out, theta.shape)

    def feasible_of(theta):
        _, qs = rhs(theta)
        out = jnp.zeros((mc.d, 2, mc.n_sizes) + theta.shape, jnp.float32)
        for (i, s, k, p, ok) in qs:
            out = out.at[i, s, k].set(ok * jnp.ones_like(p))
        return _to_controls(out, theta.shape) > 0

    def substep(theta, _):
        acc, _ = rhs(theta)
        return theta + dt_fd * acc, None

    def block(theta, _):
        theta, _ = jax.lax.scan(substep, theta, None, length=fd_substeps)
        return theta, theta

    theta_T = jnp.zeros(lat.n, jnp.float32)
    _, thetas = jax.lax.scan(block, theta_T, None, length=n_policy)
    # thetas[j] = theta(T - (j+1) dt_policy).  Reverse so that thetas[i] = theta(i * dt_policy), i = 0..n_policy-1.
    thetas = jnp.asarray(thetas)[::-1]
    quotes = jax.jit(jax.vmap(quotes_of))(thetas)           # policy used on [i dt, (i+1) dt)
    shadow = jax.jit(jax.vmap(shadow_of))(thetas)
    feasible = np.asarray(feasible_of(thetas[0]))
    t_policy = dt_policy * np.arange(n_policy)
    return FDSolution(lattice=lat, t_policy=t_policy, theta=np.asarray(thetas), quotes=np.asarray(quotes),
                      shadow=np.asarray(shadow), feasible=feasible)
