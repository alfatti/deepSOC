"""Lean, targeted tests: Hamiltonian maximiser, closed-form comparative statics,
FD monotonicity/stationarity, simulator accounting, straight-through value equality."""
import jax
import jax.numpy as jnp
import numpy as np
import pytest

from deepmm.closedform import ClosedForm
from deepmm.config import MarketConfig, TrainConfig
from deepmm.fd import solve_fd
from deepmm.intensity import HamiltonianTable, _lam_np, delta_star_np, hamiltonian_derivs_at
from deepmm.sim import StepNoise, apply_fills, make_train_loss, sample_noise

mc = MarketConfig()


def test_delta_star_matches_bruteforce():
    p = np.array([-0.3, 0.0, 0.2, 1.0])
    d = delta_star_np(p, mc)
    grid = np.linspace(-1, 6, 700001)
    for pp, dd in zip(p, d):
        L, _, _ = _lam_np(grid, mc)
        assert abs(grid[np.argmax(L * (grid - pp))] - dd) < 2e-5


def test_hamiltonian_curvature_positive():
    _, h1, h2 = hamiltonian_derivs_at(0.0, mc)
    assert h1 < 0 and h2 > 0


def test_closedform_comparative_statics():
    cf = ClosedForm.build(mc)
    lay = lambda q: np.asarray(cf.quotes(jnp.asarray(q, jnp.float32))).reshape(mc.d, 2, mc.n_sizes)
    q0, qp = lay([0.0, 0.0]), lay([50000.0, 0.0])
    # long asset 1 -> asset-1 bid further from mid, ask closer; asset-2 bid also further (rho > 0)
    assert np.all(qp[0, 0] > q0[0, 0]) and np.all(qp[0, 1] < q0[0, 1]) and np.all(qp[1, 0] > q0[1, 0])
    # larger size -> wider quote (risk buffer 1/2 sqrt(g) z Gamma_ii)
    assert np.all(np.diff(q0[:, 0, :], axis=1) > 0)
    # positive drift on asset 1 -> tighter bid than ask at q = 0
    assert np.all(q0[0, 0] < q0[0, 1])
    # magnitudes from BEGV Figs. 8-11 (closed-form curves)
    assert 0.01 < q0[0, 0, 0] < 0.03 and 0.08 < q0[1, 0, 0] < 0.12
    assert 0.17 < lay([75000.0, 0.0])[0, 0, 0] < 0.22
    assert 0.40 < lay([0.0, 300000.0])[1, 0, 0] < 0.50


def test_closedform_finite_horizon_limits():
    cf = ClosedForm.build(mc)
    q = jnp.array([20000.0, -50000.0], jnp.float32)
    assert np.allclose(np.asarray(cf.quotes_t(0.0, q)), np.asarray(cf.quotes(q)), atol=1e-4)   # ergodic at t=0
    myopic = delta_star_np(np.array([0.0]), mc)[0]
    assert np.allclose(np.asarray(cf.quotes_t(mc.T, q)), myopic, atol=1e-4)                  # A(T)=B(T)=0
    A, B = cf.AB(0.0)
    assert np.allclose(np.asarray(B), -cf.drift_shift, atol=1e-5)                            # B(0) -> -Ahat^+ mu


@pytest.fixture(scope="module")
def fd():
    return solve_fd(mc, HamiltonianTable.build(mc), dt_policy=1 / 96, fd_substeps=20)


def test_fd_monotone_and_stationary(fd):
    lat = fd.lattice
    c1, c2 = lat.n[0] // 2, lat.n[1] // 2
    q = fd.quotes[0].reshape(*lat.n, mc.d, 2, mc.n_sizes)
    bid1 = q[:-1, c2, 0, 0, 0]          # asset-1 bid along q1 (last point infeasible)
    assert np.all(np.diff(bid1) > 0)
    bid2 = q[c1, :-1, 1, 0, 0]
    assert np.all(np.diff(bid2) > 0)
    # BEGV Fig. 11: optimal asset-2 bid at q2 = 275k ~ 0.6-0.7 EUR, well above the closed form
    assert q[c1, -2, 1, 0, 0] > 0.55
    # stationarity: quotes at day 0 and day 3 agree to 1e-3
    assert np.abs(fd.quotes[0] - fd.quotes[3 * 96]).max() < 1e-3
    # value at zero inventory is the expected optimal Model-B objective (paper's PnL ~ 88.6k minus risk penalty)
    assert 40000 < fd.theta[0][c1, c2] < 80000


def test_fills_accounting_and_risk_limits():
    tc = TrainConfig(batch_size=8)
    B = 8
    q = jnp.array([[70000.0, 0.0]] * B)                     # near the asset-1 limit
    delta = jnp.full((B, mc.n_controls), -0.5)               # give-away quotes: everyone fills
    n_arr = jnp.full((B, mc.n_streams), 2)
    zidx = jnp.full((B, mc.n_streams, tc.max_arrivals), 0)  # 6250 each
    u = jnp.zeros((B, mc.n_streams, tc.max_arrivals))
    noise = StepNoise(n_arr, zidx, u, jnp.zeros((B, mc.d)))
    q1, r_exp, r_real, nf = apply_fills(q, delta, noise, mc, tc, None)
    # asset 1: both bid fills breach the limit (70000 + 6250 > 75000) and are rejected, the
    # 2 ask fills go through; asset 2: 2 bids, 2 asks
    assert np.allclose(np.asarray(q1)[0], [70000 - 12500, 0.0])
    assert np.all(np.abs(np.asarray(q1)[:, 0]) <= mc.Q[0])
    assert float(nf[0]) == 6
    assert np.isclose(float(r_real[0]), 6 * (-0.5) * 6250)
    assert np.isclose(float(r_exp[0]), float(r_real[0]), rtol=2e-3)  # p(-0.5) ~ 1


def test_straight_through_value_equals_hard():
    tc = TrainConfig(batch_size=64)
    key = jax.random.PRNGKey(0)
    noise = sample_noise(key, 64, mc, tc)
    q = jnp.zeros((64, mc.d))
    delta = jnp.full((64, mc.n_controls), 0.02)
    q_st, r_exp, _, _ = apply_fills(q, delta, noise, mc, tc, 0.05)
    q_h, _, _, _ = apply_fills(q, delta, noise, mc, tc, None)
    assert np.allclose(np.asarray(q_st), np.asarray(q_h))
    # expected reward is differentiable w.r.t. quotes and the transition has a non-zero relaxed gradient
    g = jax.grad(lambda d: apply_fills(q, d, noise, mc, tc, 0.05)[0].sum())(delta)
    assert np.isfinite(np.asarray(g)).all() and np.abs(np.asarray(g)).sum() > 0


def test_train_loss_runs_small():
    tc = TrainConfig(batch_size=16, dt=1 / 8, block_size=4, hidden=8, remat=False)
    from deepmm.policy import init_stack
    from deepmm.sim import block_of_step
    nb = int(block_of_step(mc, tc).max()) + 1
    params, bn = init_stack(jax.random.PRNGKey(0), nb, mc.d, 8, mc.n_controls)
    loss = make_train_loss(mc, tc)
    (l, stats), g = jax.value_and_grad(loss, has_aux=True)(params, bn, jax.random.PRNGKey(1), 0.05)
    assert np.isfinite(float(l))
    assert all(np.isfinite(np.asarray(v)).all() for v in jax.tree_util.tree_leaves(g))
