"""Behavioural and fit-quality tests for a *trained* checkpoint.

    DEEPMM_RUN=runs/a100 python -m pytest tests/test_policy_behaviour.py -q

Skipped when DEEPMM_RUN is unset.  Structural checks (monotonicity, drift asymmetry,
stationarity, terminal layer) must pass for any sane policy; the fit-quality checks
(median/p95 quote gap and Bellman regret no worse than the closed form it was warm-started
from) are the "did it learn anything" tests.
"""
import os
import pickle
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from deepmm.closedform import ClosedForm
from deepmm.config import MarketConfig, TrainConfig
from deepmm.diagnostics import (behavioural_checks, checks_table, ignore_args, policy_gap_on_paths,
                                regret_on_paths, visited_region)
from deepmm.evaluate import visitation
from deepmm.fd import solve_fd
from deepmm.intensity import HamiltonianTable
from deepmm.sim import nn_policy, nn_policy_fn

RUN = os.environ.get("DEEPMM_RUN")
pytestmark = pytest.mark.skipif(RUN is None, reason="set DEEPMM_RUN=<run dir with best.pkl>")


@pytest.fixture(scope="module")
def ctx():
    ck = pickle.load(open(Path(RUN) / "best.pkl", "rb"))
    mc = MarketConfig(**ck["market"]); tc = TrainConfig(**ck["train"])
    P = jax.tree_util.tree_map(jnp.asarray, ck["params"]); B = jax.tree_util.tree_map(jnp.asarray, ck["bn"])
    table = HamiltonianTable.build(mc); cf = ClosedForm.build(mc, table)
    fd = solve_fd(mc, table, dt_policy=tc.dt, fd_substeps=int(round(tc.dt * 1920)))   # ~15 s, recomputed on the fly
    pol = nn_policy_fn(mc, tc); cfp = ignore_args(cf.policy_finite_horizon(tc.dt))
    n = 2048
    gap_nn = policy_gap_on_paths(mc, tc, pol, pol, fd, n, pol_args=(P, B))
    gap_cf = policy_gap_on_paths(mc, tc, pol, cfp, fd, n, pol_args=(P, B))
    reg_nn = regret_on_paths(mc, tc, pol, pol, fd, table, n, pol_args=(P, B))
    reg_cf = regret_on_paths(mc, tc, pol, cfp, fd, table, n, pol_args=(P, B))
    region = visited_region(visitation(mc, tc, nn_policy(P, B, mc, tc), n_paths=n))
    checks = behavioural_checks(mc, tc, nn_policy(P, B, mc, tc), fd, cfp, region, gap_nn, gap_cf, reg_nn, reg_cf)
    print("\n" + checks_table(checks))
    return checks


STRUCTURAL = ["own_mono_asset1_bid", "own_mono_asset1_ask", "own_mono_asset2_bid", "own_mono_asset2_ask",
              "cross_mono_asset1_bid", "cross_mono_asset1_ask", "cross_mono_asset2_bid", "cross_mono_asset2_ask",
              "size_ordering_agrees_with_fd", "drift_asymmetry_asset1_ask_minus_bid",
              "drift_asymmetry_asset2_bid_minus_ask", "stationarity_p99_change_2d_to_T-3d",
              "terminal_layer_max_err_at_q0"]
FIT = ["median_gap_nn_vs_cf", "p95_gap_nn_vs_cf", "integrated_regret_nn_vs_cf"]


@pytest.mark.parametrize("name", STRUCTURAL)
def test_structural(ctx, name):
    c = ctx[name]
    assert c["pass"], f"{name}: value={c['value']:.4f} threshold={c['threshold']:.4f} ({c['note']})"


@pytest.mark.parametrize("name", FIT)
def test_fit_quality_beats_closed_form(ctx, name):
    c = ctx[name]
    assert c["pass"], f"{name}: nn={c['value']:.4f} closed-form={c['threshold']:.4f} ({c['note']})"
