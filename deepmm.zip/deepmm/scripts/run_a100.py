#!/usr/bin/env python
"""End-to-end run: FD benchmark -> Han & E training -> paired evaluation -> figures.
Nothing but the checkpoints (best.pkl / final.pkl), log.txt and the figures is written: the FD
solution (~15 s) and every diagnostic are recomputed on the fly whenever they are needed.

    python scripts/run_a100.py --out runs/a100 --iters 12000 --batch 16384 --eval-paths 1000000

Everything is float32; a 12k-iteration run at batch 16384 (672 steps, remat on) is
~1 hour on an A100.  Use --warm-start random for the random-init ablation.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))   # repo root, so `import deepmm` works uninstalled

import jax
import jax.numpy as jnp
import numpy as np

from deepmm.closedform import ClosedForm
from deepmm.config import MarketConfig, TrainConfig
from deepmm.evaluate import compare_policies, quote_slices, slice_errors, time_profile, visitation
from deepmm.fd import solve_fd
from deepmm.intensity import HamiltonianTable
from deepmm.sim import nn_policy
from deepmm.train import train


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="runs/a100")
    ap.add_argument("--iters", type=int, default=12000)
    ap.add_argument("--batch", type=int, default=16384)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--warm-start", default="closedform", choices=["closedform", "random"])
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--val-paths", type=int, default=65536)
    ap.add_argument("--val-every", type=int, default=500)
    ap.add_argument("--eval-paths", type=int, default=1_000_000)
    ap.add_argument("--no-fd", action="store_true", help="skip the finite-difference benchmark")
    args = ap.parse_args()

    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    logf = open(out / "log.txt", "a")

    def log(s):
        print(s, flush=True); logf.write(s + "\n"); logf.flush()

    log(f"devices: {jax.devices()}")
    mc = MarketConfig()
    tc = TrainConfig(batch_size=args.batch, n_iters=args.iters, lr=args.lr, warm_start=args.warm_start, seed=args.seed)
    table = HamiltonianTable.build(mc)
    cf = ClosedForm.build(mc, table)
    log(cf.summary())

    # ---- 1. finite-difference benchmark on the lattice
    fd = None
    if not args.no_fd:
        t0 = time.time()
        fd = solve_fd(mc, table, dt_policy=tc.dt)
        c = (fd.lattice.n[0] // 2, fd.lattice.n[1] // 2)
        log(f"FD benchmark solved in {time.time()-t0:.0f}s; theta(0, q=0) = {fd.theta[0][c]:.0f} EUR "
            f"(= optimal Model-B objective from zero inventory)")

    # ---- 2. training
    res = train(mc, tc, out_dir=out, log=log, val_paths=args.val_paths, val_every=args.val_every, fd=fd, table=table)
    params, bn = res["best_params"], res["best_bn"]
    params = jax.tree_util.tree_map(jnp.asarray, params); bn = jax.tree_util.tree_map(jnp.asarray, bn)
    pol_nn = nn_policy(params, bn, mc, tc)

    # ---- 3. paired evaluation with common random numbers
    policies = {"closedform": cf.policy(), "closedform_fh": cf.policy_finite_horizon(tc.dt), "nn": pol_nn}
    if fd is not None:
        policies = {"fd_optimal": fd.policy(), **policies}
    log(f"\n=== paired evaluation, {args.eval_paths} paths, common random numbers ===")
    compare_policies(mc, tc, policies, args.eval_paths, log=log)

    # ---- 4. quote slices, stationarity, visitation
    if fd is not None:
        sl = quote_slices(mc, fd, cf, pol_nn)
        for ax in ("q1", "q2"):
            e = slice_errors(sl, f"along_{ax}", f"mask_along_{ax}")
            log(f"RMS bid-quote error vs FD along {ax} (all assets/sizes, feasible points): "
                + ", ".join(f"{k}={v*100:.2f} cents" for k, v in e.items()))
        tp = time_profile(mc, tc, pol_nn, fd)
        vis = visitation(mc, tc, pol_nn)
        try:
            from figures import make_figures
            make_figures(mc, sl, tp, vis, res["history"], out)
            log(f"figures written to {out}")
        except Exception as e:  # matplotlib optional
            log(f"figures skipped: {e}")
    log("done.")


if __name__ == "__main__":
    main()
