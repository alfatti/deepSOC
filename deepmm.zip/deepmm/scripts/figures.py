"""Figures for the run: BEGV Figs. 8-11 with the network added, learning curve,
time profile of the quotes at q = 0, and the state-visitation histogram."""
from __future__ import annotations

from pathlib import Path

import numpy as np


def make_figures(mc, sl, tp, vis, history, out: Path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    size_names = ["very small", "small", "large", "very large"]
    fig, axes = plt.subplots(2, 2, figsize=(13, 9))
    panels = [(0, "q1", "asset 1 bid vs q1 (q2=0)"), (0, "q2", "asset 1 bid vs q2 (q1=0)"),
              (1, "q1", "asset 2 bid vs q1 (q2=0)"), (1, "q2", "asset 2 bid vs q2 (q1=0)")]
    for ax, (asset, axis, title) in zip(axes.flat, panels):
        x = sl[axis]
        m = sl[f"mask_along_{axis}"][:, asset, :]
        for k in range(mc.n_sizes):
            mk = m[:, k]
            ax.plot(x[mk], sl[f"fd_along_{axis}"][mk, asset, k], "k.", ms=3, label="FD optimal" if k == 0 else None)
            ax.plot(x[mk], sl[f"cf_along_{axis}"][mk, asset, k], color="0.6", marker="v", ls="", ms=3,
                    label="closed form" if k == 0 else None)
            if f"nn_along_{axis}" in sl:
                ax.plot(x[mk], sl[f"nn_along_{axis}"][mk, asset, k], color="C3", marker="+", ls="", ms=4,
                        label="deep control (Han-E)" if k == 0 else None)
        ax.set_title(title); ax.set_xlabel(axis); ax.set_ylabel("bid quote delta (EUR)"); ax.grid(alpha=.3)
        ax.legend(fontsize=8)
    fig.suptitle("Bid quotes at t=0, all four request sizes (cf. BEGV Figs. 8-11)")
    fig.tight_layout(); fig.savefig(out / "quote_slices.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    it = np.asarray(history["iter"]); ax[0].plot(it, -np.asarray(history["loss"]) / 1e-3, lw=.8)
    ax[0].set_xlabel("iteration"); ax[0].set_ylabel("training objective (EUR, train-mode BN)"); ax[0].grid(alpha=.3)
    ax[1].plot(np.arange(len(history["val_obj"])), history["val_obj"], "o-")
    ax[1].set_xlabel("validation index"); ax[1].set_ylabel("validation objective (EUR)"); ax[1].grid(alpha=.3)
    fig.tight_layout(); fig.savefig(out / "learning_curve.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    lay = lambda a: a.reshape(a.shape[0], mc.d, 2, mc.n_sizes)
    for i, a in enumerate(["nn", "fd"]):
        q = lay(tp[a])
        for asset in range(mc.d):
            ax[i].plot(tp["t"], q[:, asset, 0, 0], label=f"asset {asset+1} bid")
            ax[i].plot(tp["t"], q[:, asset, 1, 0], "--", label=f"asset {asset+1} ask")
        ax[i].set_title(f"{a}: quotes at q=0 vs time (very small size)"); ax[i].set_xlabel("t (days)"); ax[i].grid(alpha=.3)
        ax[i].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(out / "time_profile.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 5))
    h = mc.lattice_step
    ext = [-mc.Q[1] - h / 2, mc.Q[1] + h / 2, -mc.Q[0] - h / 2, mc.Q[0] + h / 2]
    im = ax.imshow(np.log10(vis + 1e-9), extent=ext, aspect="auto", origin="lower", cmap="viridis")
    ax.set_xlabel("q2"); ax.set_ylabel("q1"); ax.set_title("log10 state-visitation frequency (NN policy, q0=0)")
    fig.colorbar(im); fig.tight_layout(); fig.savefig(out / "visitation.png", dpi=130); plt.close(fig)
